from setuptools import setup

setup(
    
    name="segunda_preEntrega_Luchelli",
    version="1.0",
    description="Segunda preEntrega",
    author="Federico Luchelli",
    author_email="luchellifederico@gmail.com",
    
    packages=["paquete"]
)